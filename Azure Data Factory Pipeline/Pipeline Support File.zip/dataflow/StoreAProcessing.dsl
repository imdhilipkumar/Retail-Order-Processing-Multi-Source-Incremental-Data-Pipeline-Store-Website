parameters{
	pbatchend as string,
	pwebwatermark as string,
	pstoreawatermark as string
}
source(output(
		invoice_no as string,
		cust_no as string,
		bill_date as string,
		bill_time as string,
		bill_status as string,
		payment_mode as string,
		updated_at as string
	),
	allowSchemaDrift: false,
	validateSchema: true,
	ignoreNoFilesFound: true,
	rowUrlColumn: 'ordersourcepath',
	wildcardPaths:['/storea/order_????????_????.csv']) ~> SRCStoreorder
source(output(
		invoice_no as string,
		line_no as string,
		item_code as string,
		product_name as string,
		qty as string,
		rate as string,
		disc_pct as string
	),
	allowSchemaDrift: false,
	validateSchema: true,
	ignoreNoFilesFound: true,
	rowUrlColumn: 'itemsourcepath',
	wildcardPaths:['/storea/order_items_????????_????.csv']) ~> SRCStoreorderitem
source(output(
		customer as (customer_id as string, email as string),
		delivery as (city as string, delivery_fee as double, delivery_type as string),
		items as (line_no as short, price as double, promotions as (amount as double, code as string)[], quantity as short, sku as string)[],
		order_date as string,
		order_id as string,
		payment as (method as string, transaction_id as string),
		status as string,
		updated_at as string
	),
	allowSchemaDrift: true,
	validateSchema: false,
	ignoreNoFilesFound: true,
	rowUrlColumn: 'websourcepath',
	documentForm: 'arrayOfDocuments',
	wildcardPaths:['website/*.json']) ~> SRCWEBDATA
FLORDER, FLITEM join(storeaorder_ts == item_ts
	&& SRCStoreorder@invoice_no == SRCStoreorderitem@invoice_no,
	joinType:'inner',
	matchType:'exact',
	ignoreSpaces: false,
	broadcast: 'auto')~> SRCorderdata
SRCSELECTION cast(output(
		updated_at as timestamp 'dd-MM-yyyy HH:mm',
		line_no as integer,
		qty as integer,
		rate as decimal(10,0),
		disc_pct as integer
	),
	errors: true) ~> SRCCastOrder
SRCCastOrder split(isError(),
	disjoint: false) ~> SRCSPLIT@(TYPEERROR, VALIDDATA)
SRCSPLIT@VALIDDATA assert(expectTrue(lower(bill_status)=='paid', false, 'VALIDSTATUS'),
	expectTrue(!isNull(invoice_no) && !isNull(cust_no), false, 'VALIDNULLS')) ~> SRCASSERT
SRCorderdata select(mapColumn(
		invoice_no = SRCStoreorder@invoice_no,
		cust_no,
		bill_date,
		bill_time,
		bill_status,
		payment_mode,
		updated_at,
		line_no,
		item_code,
		product_name,
		qty,
		rate,
		disc_pct
	),
	skipDuplicateMapInputs: false,
	skipDuplicateMapOutputs: false) ~> SRCSELECTION
SRCASSERT split(isError(),
	disjoint: false) ~> SRCSPLIT2@(DATAERROR, VALIDDATA2)
SRCSPLIT2@VALIDDATA2 derive(net_amount = (qty*rate) - ((qty*rate)*disc_pct/100),
		gross_amount = qty*rate,
		delivery_fee = 0,
		scource_channel = 'STORE A',
		time_processing = currentTimestamp(),
		billed_at = toTimestamp(bill_date+' '+bill_time, 'dd-MM-yyyy HH:mm:ss')) ~> SRCDERIVED
SRCDERIVED select(mapColumn(
		invoice_number = invoice_no,
		customer_number = cust_no,
		line_number = line_no,
		bill_date = billed_at,
		bill_status,
		payment_mode,
		quantity = qty,
		unit_price = rate,
		net_amount,
		gross_amount,
		delivery_fee,
		source_channel = scource_channel,
		time_processing
	),
	skipDuplicateMapInputs: false,
	skipDuplicateMapOutputs: false) ~> SRCStoreAFinalData
FLWEB foldDown(unroll(items),
	mapColumn(
		order_id,
		customer = customer.customer_id,
		email = customer.email,
		order_date,
		status,
		payment = payment.method,
		transaction_id = payment.transaction_id,
		delivery = delivery.delivery_type,
		delivery_fee = delivery.delivery_fee,
		city = delivery.city,
		updated_at,
		items = items.line_no,
		sku = items.sku,
		quantity = items.quantity,
		price = items.price,
		promotions = items.promotions
	),
	skipDuplicateMapInputs: false,
	skipDuplicateMapOutputs: false) ~> WEBFlatten
WEBFlatten foldDown(unroll(promotions),
	mapColumn(
		order_id,
		customer,
		email,
		order_date,
		status,
		payment,
		transaction_id,
		delivery,
		delivery_fee,
		city,
		updated_at,
		items,
		sku,
		quantity,
		price,
		promotions = promotions.code,
		amount = promotions.amount
	),
	skipDuplicateMapInputs: false,
	skipDuplicateMapOutputs: false) ~> WEBFlatten2
WEBFlatten2 derive(processing_amount_clean = coalesce(amount,0.0)) ~> WEBDRV
WEBDRV aggregate(groupBy(order_id,
		sku),
	discount_amount = sum(processing_amount_clean),
		customer_id = first(customer),
		customer_email = first(email),
		product_id = first(sku),
		order_at = first(order_date),
		status = first(status),
		payment = first(payment),
		transaction_id = first(transaction_id),
		delivery_fee = first(delivery_fee),
		updated_at = first(updated_at),
		quantity = first(quantity),
		unit_price = first(price),
		line_no = first(items)) ~> WEBAGG
WEBAGG derive(gross_amount = quantity*unit_price,
		net_amount = (quantity*unit_price)-discount_amount,
		clean_delivery_fee = iif(line_no==1, delivery_fee, toDouble(0.0)),
		source_channel = 'WEB',
		time_processing = currentTimestamp()) ~> WEBDRV2
WEBDRV2 assert(expectTrue(!isNull(order_id) && !isNull(customer_id), false, 'VALIDROWS'),
	expectTrue(quantity>0&&net_amount>0, false, 'VALIDQTY'),
	expectTrue(lower(status)=='completed', false, 'VALIDSTATUS')) ~> WEBAssert
WEBAssert split(isError(),
	disjoint: false) ~> WEBSPLIT@(DATAERRORWEB, WEBVALIDATA)
WEBSPLIT@WEBVALIDATA cast(output(
		order_at as timestamp 'yyyy-MM-dd\'T\'HH:mm:ss',
		updated_at as timestamp 'yyyy-MM-dd\'T\'HH:mm:ss'
	),
	errors: true) ~> WEBCAST
WEBCAST select(mapColumn(
		invoice_number = order_id,
		customer_number = customer_id,
		line_number = line_no,
		bill_date = order_at,
		bill_status = status,
		payment_mode = payment,
		quantity,
		unit_price,
		gross_amount,
		net_amount,
		delivery_fee = clean_delivery_fee,
		source_channel,
		time_processing
	),
	skipDuplicateMapInputs: true,
	skipDuplicateMapOutputs: true) ~> WEBFINAL
WEBFINAL, SRCStoreAFinalData union(byName: true)~> UnionFinalData
SRCStoreorder derive(storeaorder_ts = toTimestamp(
    concat(
	   substring(regexExtract(ordersourcepath,`order_(\d{8})_(\d{4})\.csv`,1),1,4),'-',
	   substring(regexExtract(ordersourcepath,`order_(\d{8})_(\d{4})\.csv`,1),5,2),'-',
	   substring(regexExtract(ordersourcepath,`order_(\d{8})_(\d{4})\.csv`,1),7,2),'T',
	   substring(regexExtract(ordersourcepath,`order_(\d{8})_(\d{4})\.csv`,2),1,2),':',
	   substring(regexExtract(ordersourcepath,`order_(\d{8})_(\d{4})\.csv`,2),3,2),':00'
    ),
    'yyyy-MM-dd\'T\'HH:mm:ss'
)) ~> DRVORDERTIME
DRVORDERTIME filter(storeaorder_ts > toTimestamp(substring($pstoreawatermark,1,19), 'yyyy-MM-dd\'T\'HH:mm:ss')
&&
storeaorder_ts <= toTimestamp($pbatchend, 'yyyy-MM-dd\'T\'HH:mm:ss')) ~> FLORDER
SRCStoreorderitem derive(item_ts = toTimestamp(
    concat(
	   substring(regexExtract(itemsourcepath,`order_items_(\d{8})_(\d{4})\.csv`,1),1,4),'-',
	   substring(regexExtract(itemsourcepath,`order_items_(\d{8})_(\d{4})\.csv`,1),5,2),'-',
	   substring(regexExtract(itemsourcepath,`order_items_(\d{8})_(\d{4})\.csv`,1),7,2),'T',
	   substring(regexExtract(itemsourcepath,`order_items_(\d{8})_(\d{4})\.csv`,2),1,2),':',
	   substring(regexExtract(itemsourcepath,`order_items_(\d{8})_(\d{4})\.csv`,2),3,2),':00'
    ),
    'yyyy-MM-dd\'T\'HH:mm:ss'
)) ~> DRVITEM
DRVITEM filter(item_ts > toTimestamp(substring($pstoreawatermark,1,19), 'yyyy-MM-dd\'T\'HH:mm:ss')
&&
item_ts <= toTimestamp($pbatchend, 'yyyy-MM-dd\'T\'HH:mm:ss')) ~> FLITEM
SRCWEBDATA derive(web_ts = toTimestamp(
    concat(
	   substring(regexExtract(websourcepath,`orders_(\d{8})_(\d{4})\.json`,1),1,4),'-',
	   substring(regexExtract(websourcepath,`orders_(\d{8})_(\d{4})\.json`,1),5,2),'-',
	   substring(regexExtract(websourcepath,`orders_(\d{8})_(\d{4})\.json`,1),7,2),'T',
	   substring(regexExtract(websourcepath,`orders_(\d{8})_(\d{4})\.json`,2),1,2),':',
	   substring(regexExtract(websourcepath,`orders_(\d{8})_(\d{4})\.json`,2),3,2),':00'
    ),
    'yyyy-MM-dd\'T\'HH:mm:ss'
)) ~> DRVWEB
DRVWEB filter(web_ts > toTimestamp(substring($pstoreawatermark,1,19), 'yyyy-MM-dd\'T\'HH:mm:ss')
&&
web_ts <= toTimestamp($pbatchend, 'yyyy-MM-dd\'T\'HH:mm:ss')) ~> FLWEB
UnionFinalData sink(allowSchemaDrift: true,
	validateSchema: false,
	format: 'parquet',
	skipDuplicateMapInputs: true,
	skipDuplicateMapOutputs: true,
	mapColumn(
		invoice_number,
		customer_number,
		line_number,
		bill_date,
		bill_status,
		payment_mode,
		quantity,
		unit_price,
		gross_amount,
		net_amount,
		delivery_fee,
		source_channel,
		time_processing
	)) ~> SINKFINALDATA
SRCSPLIT@TYPEERROR sink(allowSchemaDrift: true,
	validateSchema: false,
	partitionFileNames:[(concat('storea_typeerror', toString(toTimestamp($pbatchend,"yyyy-MM-dd'T'HH:mm:ss"), 'yyyymmdd_HHmm')))],
	skipDuplicateMapInputs: true,
	skipDuplicateMapOutputs: true,
	partitionBy('hash', 1)) ~> STATPER
SRCSPLIT2@DATAERROR sink(allowSchemaDrift: true,
	validateSchema: false,
	partitionFileNames:[(concat('storea_dataerror', toString(toTimestamp($pbatchend,"yyyy-MM-dd'T'HH:mm:ss"), 'yyyymmdd_HHmm')))],
	skipDuplicateMapInputs: true,
	skipDuplicateMapOutputs: true,
	partitionBy('hash', 1)) ~> sink1